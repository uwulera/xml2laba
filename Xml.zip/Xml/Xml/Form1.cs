﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace Xml
{
    public partial class Form1 : Form
    {
        private static int count = 0;


        public Form1()
        {
            InitializeComponent();
            Plant();
        }




        private void Plant()
        {
            //var serializer = new XmlSerializer(typeof(Catalog));
            //var catalogFromXml = new List<Plant>();

            //using (var reader = new FileStream("catalog.xml", FileMode.Open))
            //{
            //    catalogFromXml = ((Catalog)serializer.Deserialize(reader)).Items;
            //}

            //foreach (var plant in catalogFromXml)
            //{
            //    listBox1.Items.Add(plant);
            //}
        }
        public abstract class PlantsElem
        {
            public abstract List<Plant> RetList();
        }


        abstract class checkConsole
        {
            public void check()
            {
                Console.WriteLine("все работает");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "XML|*.xml";
            if (ofd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {

                var serializer = new XmlSerializer(typeof(Catalog));
                var NoteFromXml = new List<Plant>();
                try
                {
                    listBox1.Items.Clear();
                    using (var reader = new FileStream(ofd.FileName, FileMode.Open))
                    {
                        NoteFromXml = ((Catalog)serializer.Deserialize(reader)).Items;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"ValidatingReaderExample.Exception: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                foreach (var note in NoteFromXml)
                {
                    listBox1.Items.Add(note);

                }

            }
        }
    }
}

