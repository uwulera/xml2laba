﻿using System.Xml.Serialization;
using static System.Net.Mime.MediaTypeNames;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace Xml
{
    public class Plant
    {
        [XmlElement("common")]
        public string Common { get; set; }

        [XmlElement("botanical")]
        public string Botanical { get; set; }

        [XmlElement("zone")]
        public double Zone { get; set; }

        [XmlElement("light")]
        public string Light { get; set; }

        [XmlElement("price")]
        public double Price { get; set; }

        [XmlElement("availability")]
        public int Availability { get; set; }

        public override string ToString()
        {
            return $"{nameof(Common)}:{Common}; " +
                   $"{nameof(Botanical)}:{Botanical}; " +
                   $"{nameof(Zone)}:{Zone}; " +
                   $"{nameof(Light)}:{Light}; " +
                   $"{nameof(Price)}:{Price};"+
                   $"{nameof(Availability)}:{Availability};";
        }
    }

}
