﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace Xml
{
    [XmlRoot("catalog")]
    public class Catalog
    {
        [XmlElement("plant")]
        public List<Plant> Items { get; set; }
    }
}
