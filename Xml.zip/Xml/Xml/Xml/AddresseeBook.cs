﻿using System.Collections.Generic;
using System.Xml.Serialization;

namespace Xml
{
    [XmlRoot("addressbook")]
    public class AddresseeBook
    {
        [XmlElement("address")]
        public List<Address> Items { get; set; }
    }
}
