﻿using System.Xml.Serialization;

namespace Xml
{
    public class Address
    {
        [XmlElement("common")]
        public string Common { get; set; }

        [XmlElement("streetaddress")]
        public string StreetAddress { get; set; }

        [XmlElement("city")]
        public string City { get; set; }

        [XmlElement("state")]
        public string State { get; set; }

        [XmlElement("postalCode")]
        public int PostalCode { get; set; }

        public override string ToString()
        {
            return $"{nameof(Common)}:{Common}; " +
                   $"{nameof(StreetAddress)}:{StreetAddress}; " +
                   $"{nameof(City)}:{City}; " +
                   $"{nameof(State)}:{State}; " +
                   $"{nameof(PostalCode)}:{PostalCode};";
        }
    }
}
