﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Serialization;

namespace Xml
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            Address();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex != -1)
            {
                propertyGrid1.SelectedObject = listBox1.SelectedItem;
            }
        }

        private void Address()
        {
            var serializer = new XmlSerializer(typeof(AddresseeBook));
            var addressBookFromXml = new List<Address>();

            using (var reader = new FileStream("test.xml", FileMode.Open))
            {
                addressBookFromXml = ((AddresseeBook)serializer.Deserialize(reader)).Items;
            }

            foreach (var address in addressBookFromXml)
            {
                listBox1.Items.Add(address);
            }
        }

        private void propertyGrid1_Click(object sender, EventArgs e)
        {

        }
    }
}
